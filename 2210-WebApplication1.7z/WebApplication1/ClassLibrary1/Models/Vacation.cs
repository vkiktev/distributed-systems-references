﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace ClassLibrary1
{
    public class Vacation
    {
        public int Id { get; set; }

        public int EmployeeId { get; set; }

        public Employee Employee { get; set; }

        public int TypeId { get; set; }

        public VacationType VacationType { get; set; }

        public DateTime DateFrom { get; set; }

        public DateTime DateTo { get; set; }

        public int[] GetDays(string month)
        {
            var dtInfo = new DateTimeFormatInfo();
            var days = new List<int>();
            for (var date = DateFrom; date <= DateTo; date.AddDays(1))
            {
                if (dtInfo.GetMonthName(date.Month) == month)
                {
                    days.Add(date.Day);
                }
            }
            return days.ToArray();
        }
    }
}
