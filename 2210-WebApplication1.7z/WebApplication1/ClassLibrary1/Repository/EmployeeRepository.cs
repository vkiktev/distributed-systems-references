﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary1.Repository
{
    class EmployeeRepository
    {
        public readonly string _selectAllQuery = "";
    }
}
