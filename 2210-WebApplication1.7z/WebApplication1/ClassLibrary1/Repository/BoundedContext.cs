﻿using System;
using System.Collections.Generic;
using System.Text;
using Dapper;
using System.Data;
using System.Data.SQLite;

namespace ClassLibrary1.Repository
{
    public class BoundedContext
    {
        public List<Employee> GetEmployees()
        {
            string connectionString = "Data Source=./db/vdb.db;Version=3;";
            using (IDbConnection connection = new SQLiteConnection(connectionString))
            {
                connection.ExecuteAsync("");
            }
                return null;
        }
    }
}
