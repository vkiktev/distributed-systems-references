﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassLibrary1.Repository
{
    class VacationRepository
    {
        private readonly string _getAllQuery = @"SELECT emp.Id
                                                      , emp.Name
                                                      , vac.Id
                                                      , vac.TypeId
                                                      , vac.DateFrom
                                                      , vac.DateTo
                                                      , type.Id
                                                      , type.Name 
                                                 FROM Employee emp 
                                                 JOIN Vacation vac ON emp.Id = vac.EmployeeId
                                                 JOIN VacationType type ON type.Id = vac.TypeId";


    }
}
