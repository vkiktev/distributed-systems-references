using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    public class SampleDataController : Controller
    {
        private static string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private static List<CalendarItem> Items = new List<CalendarItem>()
        {
            new CalendarItem() { Employee = "Ivanov", Days = new VacationDay[] { new VacationDay("January", 1, "Sick"), new VacationDay("January", 2, "Sick") } },
            new CalendarItem() { Employee = "Petrov", Days = new VacationDay[] { new VacationDay("January", 10, "Vacation"), new VacationDay("January", 11, "Vacation"), new VacationDay("January", 12, "Vacation"), new VacationDay("January", 13, "Vacation") } },
            new CalendarItem() { Employee = "Sidorov", Days = new VacationDay[] { new VacationDay("January", 20, "Vacation"), new VacationDay("January", 21, "Vacation") } },
            new CalendarItem() { Employee = "Kozlov", Days = new VacationDay[] { new VacationDay("February", 1, "Vacation"), new VacationDay("February", 2, "Vacation") } }
        };

        private static List<MonthItem> Months = new List<MonthItem>()
        {
            new MonthItem(1, "January", 31),
            new MonthItem(2, "February", 28),
            new MonthItem(3, "March", 31),
            new MonthItem(4, "April", 30),
            new MonthItem(5, "May", 31),
            new MonthItem(6, "June", 30),
            new MonthItem(7, "July", 31),
            new MonthItem(8, "August", 31),
            new MonthItem(9, "September", 30),
            new MonthItem(10, "October", 31),
            new MonthItem(11, "November", 30),
            new MonthItem(12, "December", 31)
        };

        [HttpGet("[action]")]
        public IEnumerable<WeatherForecast> WeatherForecasts(int startDateIndex)
        {
            var rng = new Random();
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                DateFormatted = DateTime.Now.AddDays(index + startDateIndex).ToString("d"),
                TemperatureC = rng.Next(-20, 55),
                Summary = Summaries[rng.Next(Summaries.Length)]
            });
        }

        [HttpGet("[action]")]
        public Calendar VacationsCalendar(int currentMonth)
        {
            var itemIndex = currentMonth > 12 ? 1 : (currentMonth < 1 ? 12 : currentMonth);
            var item = Months[itemIndex - 1];

            Calendar calendar = new Calendar();
            calendar.CurrentMonth = item.Number;
            calendar.CountDays = item.Days;

            calendar.CalendarItems = Items.Where(x => x.Days.Any(c => c.Month == item.Name)).ToArray();
            
            return calendar;
        }

        public class WeatherForecast
        {
            public string DateFormatted { get; set; }
            public int TemperatureC { get; set; }
            public string Summary { get; set; }

            public int TemperatureF
            {
                get
                {
                    return 32 + (int)(TemperatureC / 0.5556);
                }
            }
        }

        public class MonthItem
        {
            public MonthItem(int number, string name, short days)
            {
                Number = number;
                Name = name;
                Days = days;
            }
            public int Number { get; set; }

            public string Name { get; set; }

            public short Days { get; set; }
        }

        public class Calendar
        {
            public int CurrentMonth { get; set; }

            public int CountDays { get; set; }

            public CalendarItem[] CalendarItems { get; set; }
        }

        public class CalendarItem
        {
            public string Employee { get; set; }
            public VacationDay[] Days { get; set; }
        }

        public class VacationDay
        {
            public VacationDay(string month, short day, string type)
            {
                Month = month;
                Day = day;
                Type = type;
            }

            public string Month { get; set; }

            public short Day { get; set; }

            public string Type { get; set; }
        }
    }
}
