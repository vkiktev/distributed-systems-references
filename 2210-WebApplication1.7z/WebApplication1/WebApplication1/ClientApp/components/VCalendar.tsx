import * as React from 'react';
import { Link, RouteComponentProps } from 'react-router-dom';
import { connect } from 'react-redux';
import { ApplicationState } from '../store';
import * as VacationsCalendar from '../store/VacationsCalendar';
import Select from 'react-select';

// At runtime, Redux will merge together...
type VacationCalendarProps =
    VacationsCalendar.VacationsCalendarState        // ... state we've requested from the Redux store
    & typeof VacationsCalendar.actionCreators      // ... plus action creators we've requested
    & RouteComponentProps<{ currentMonth: number }>; // ... plus incoming routing parameters

class CalendarData extends React.Component<VacationCalendarProps, {}> {
    componentWillMount() {
        // This method runs when the component is first added to the page
        let currentMonth = this.props.match.params.currentMonth || 1;
        this.props.requestVacationsCalendar(currentMonth);
    }

    componentWillReceiveProps(nextProps: VacationCalendarProps) {
        // This method runs when incoming props (e.g., route params) change
        let currentMonth = nextProps.match.params.currentMonth || 1;
        this.props.requestVacationsCalendar(currentMonth);
    }

    public render() {
        return <div>
            <h1>Vacation calendar</h1>
            <p>This component demonstrates fetching data from the server and working with URL parameters.</p>
            <p>{this.props.calendar.currentMonth}, {this.props.calendar.countDays}</p>
            { this.renderNewCalendarItemForm() }
            <hr/>
            { this.renderVacationCalendarTable() }
            { this.renderPagination() }
        </div>;
    }

    private renderNewCalendarItemForm() {
        var daysFrom = [];
        var daysTo = [];

        for (var i = 1; i <= this.props.calendar.countDays; i++) {
            daysFrom.push({ value: i, lavel: i });
            daysTo.push({ value: i, lavel: i });
        }

        return <div>
            <h1>New vacation</h1>
            <p><input id="employee" label="Employee:" value={this.props.newCalendarItem.employee} /></p>
            <p><Select
                options={daysFrom}
                simpleValue
                value={this.props.newCalendarItem.newDayFrom} />
            </p>
            <p><Select
                options={daysTo}
                simpleValue
                value={this.props.newCalendarItem.newDayTo} />
            </p>

            <button onClick={() => { alert("Added"); }}>Add</button>
        </div>;
    }

    private renderVacationCalendarTable() {
        var header: JSX.Element[] = [];
        for (var i = 1; i <= this.props.calendar.countDays; i++) {
            header.push(<th>{i}</th>);
        }

        var row: JSX.Element[] = [];
        for (var i = 1; i <= this.props.calendar.countDays; i++) {
            row.push(<td></td>);
        }

        return <table className='table'>
            <thead>
                <tr>
                    <th>Employee</th>
                    {header}
                </tr>
            </thead>
            <tbody>                
                {this.props.calendar.calendarItems.map(item =>
                <tr key={item.employee}>
                        <td>{item.employee}</td>
                        {row}
                </tr>
            )}
            </tbody>
        </table>;
    }

    private renderPagination() {
        let prevStartDateIndex = Number(this.props.currentMonth) - 1;
        let nextStartDateIndex = Number(this.props.currentMonth) + 1;

        if (prevStartDateIndex == 0) {
            prevStartDateIndex = 1;
        }

        if (nextStartDateIndex == 13) {
            nextStartDateIndex = 12;
        }

        return <p className='clearfix text-center'>
            <Link className='btn btn-default pull-left' to={ `/vacations/${ prevStartDateIndex }` }>Previous</Link>
            <Link className='btn btn-default pull-right' to={ `/vacations/${ nextStartDateIndex }` }>Next</Link>
            { this.props.isLoading ? <span>Loading...</span> : [] }
        </p>;
    }
}

export default connect(
    (state: ApplicationState) => state.calendar, // Selects which state properties are merged into the component's props
    VacationsCalendar.actionCreators                 // Selects which action creators are merged into the component's props
)(CalendarData) as typeof CalendarData;
