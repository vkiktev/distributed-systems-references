import { fetch, addTask } from 'domain-task';
import { Action, Reducer, ActionCreator } from 'redux';
import { AppThunkAction } from './';

// -----------------
// STATE - This defines the type of data maintained in the Redux store.

export interface VacationsCalendarState {
    isLoading: boolean;
    calendar: Calendar;
    currentMonth: number;
    newCalendarItem: CalendarItem;
    errorMessage: string;
}

export interface Calendar {
    currentMonth: number;
    countDays: number;
    calendarItems: CalendarItem[];
}

export interface CalendarItem {
    employee: string;
    days: VacationDay[];
    newDayFrom: number;
    newDayTo: number;
}

export interface VacationDay {
    day: number;
    type: string;
    month: string;
}

// -----------------
// ACTIONS - These are serializable (hence replayable) descriptions of state transitions.
// They do not themselves have any side-effects; they just describe something that is going to happen.

interface RequestVacationsCalendarAction {
    type: 'REQUEST_CALENDAR';
    currentMonth: number;
}

interface ReceiveVacationsCalendarAction {
    type: 'RECEIVE_CALENDAR';
    currentMonth: number;
    calendar: Calendar;
}

// Declare a 'discriminated union' type. This guarantees that all references to 'type' properties contain one of the
// declared type strings (and not any other arbitrary string).
type KnownAction = RequestVacationsCalendarAction | ReceiveVacationsCalendarAction;

// ----------------
// ACTION CREATORS - These are functions exposed to UI components that will trigger a state transition.
// They don't directly mutate state, but they can have external side-effects (such as loading data).

export const actionCreators = {
    requestVacationsCalendar: (currentMonth: number): AppThunkAction<KnownAction> => (dispatch, getState) => {
        // Only load data if it's something we don't already have (and are not already loading)
        if (currentMonth !== getState().calendar.currentMonth) {
            let fetchTask = fetch(`api/SampleData/VacationsCalendar?currentMonth=${currentMonth}`)
                .then(response => response.json() as Promise<Calendar>)
                .then(data => {
                    console.log('Data: ' + JSON.stringify(data));
                    dispatch({ type: 'RECEIVE_CALENDAR', currentMonth: currentMonth, calendar: data });
                }).catch(function (error) {
                    console.log('Fetch error: ' + error.message);
                });

            addTask(fetchTask); // Ensure server-side prerendering waits for this to complete
            dispatch({ type: 'REQUEST_CALENDAR', currentMonth: currentMonth });
        }
    }
};

// ----------------
// REDUCER - For a given state and action, returns the new state. To support time travel, this must not mutate the old state.

const unloadedState: VacationsCalendarState = { calendar: { currentMonth: 1, countDays: 0, calendarItems: [] }, currentMonth: 1, isLoading: false, newCalendarItem: { employee: "", days: [], newDayFrom: 1, newDayTo: 1 }, errorMessage: "" };

export const reducer: Reducer<VacationsCalendarState> = (state: VacationsCalendarState, incomingAction: Action) => {
    const action = incomingAction as KnownAction;
    switch (action.type) {
        case 'REQUEST_CALENDAR':
            return {
                currentMonth: action.currentMonth,
                calendar: state.calendar,
                isLoading: true,
                newCalendarItem: state.newCalendarItem,
                errorMessage: state.errorMessage
            };
        case 'RECEIVE_CALENDAR':
            // Only accept the incoming data if it matches the most recent request. This ensures we correctly
            // handle out-of-order responses.
            if (action.currentMonth === state.currentMonth) {
                return {
                    currentMonth: action.currentMonth,
                    calendar: action.calendar,
                    isLoading: false,
                    newCalendarItem: { employee: "", days: [], newDayFrom: 1, newDayTo: 1 },
                    errorMessage: ""
                };
            }
            break;
        default:
            // The following line guarantees that every action in the KnownAction union has been covered by a case above
            const exhaustiveCheck: never = action;
    }

    return state || unloadedState;
};
